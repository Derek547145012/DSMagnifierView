//
//  DSMagnifierView.h
//  FootSize
//
//  Created by iBahs on 2017/8/31.
//  Copyright © 2017年 avtrace-iBahs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DSMagnifierView : UIWindow

@property (nonatomic, strong) UIView *renderView;
@property (nonatomic, assign) CGPoint renderPoint;

@end
