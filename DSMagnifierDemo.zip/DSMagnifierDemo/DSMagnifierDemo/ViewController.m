//
//  ViewController.m
//  DSMagnifierDemo
//
//  Created by 宋利军 on 2018/3/10.
//  Copyright © 2018年 silas. All rights reserved.
//

#import "ViewController.h"
#import "DSMagnifierView.h"

@interface ViewController ()

@property (strong, nonatomic) DSMagnifierView *magnifierView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesMoved:touches withEvent:event];
    
    NSLog(@"touching");
    
    // 获取触摸点
    UITouch *touch = [touches anyObject];
    CGPoint p = [touch locationInView:self.view];
    
    //window的hidden默认为YES
    self.magnifierView.hidden = NO;
    
    //设置magnifierView的frame
    self.magnifierView.frame = CGRectMake(0, 0, 150, 150);
    self.magnifierView.center = p;
    
    //设置渲染的中心点
    self.magnifierView.renderPoint = p;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    
    //用完一定要记得置nil。
    self.magnifierView = nil;
}

- (DSMagnifierView *)magnifierView {
    if (nil == _magnifierView) {
        _magnifierView = [[DSMagnifierView alloc] init];
        _magnifierView.renderView = self.view.window;
    }
    return _magnifierView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
